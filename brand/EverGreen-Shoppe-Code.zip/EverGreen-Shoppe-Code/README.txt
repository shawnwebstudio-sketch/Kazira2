EVER GREEN SHOPPE - WEBSITE CODE
Handover date: 13 November 2026
Website: https://evergreenshoppe.in

FILES

index.html
  The complete website code: the design, all pages, the product
  catalogue and prices, and the WhatsApp ordering. Products and prices
  are in the PRODUCTS / WB / WG lists inside this file.

CNAME
  Tells GitHub Pages to serve the site at evergreenshoppe.in.

product-list.json
  The product photo list.

IMAGES ARE NOT INCLUDED

The images (product photos, banners, logos) are not in this zip.
index.html loads them from an img/ folder placed next to it.

HOSTING AND DOMAIN

The site is hosted on GitHub Pages.
The domain evergreenshoppe.in is registered at GoDaddy.

DNS records at GoDaddy:
  4 A records:
    185.199.108.153
    185.199.109.153
    185.199.110.153
    185.199.111.153
  www: CNAME record.

ORDERS

There is no online payment. Orders go to WhatsApp +91 79046 98007.

PHOTO CREDIT

The temple photo is by Madhuranthakan Jagadeesan, licensed CC BY-SA 4.0.
The licence requires the credit to stay visible in the site footer.

Website by shawn webstudio.
