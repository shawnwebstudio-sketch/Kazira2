EVER GREEN SHOPPE - WEBSITE HANDOVER
Handover date: 13 November 2026
Website: https://evergreenshoppe.in

WHAT IS IN THIS ZIP

1-Website
  The complete live website, exactly as it is online.
  - index.html: the whole site (design, pages, product catalogue and code).
  - img/: every image used on the site. That includes the product photos
    (img/wa), the banners, the temple photos (img/real) and the logos.
  - wa/: the product photo list.
  - CNAME: tells GitHub Pages to serve the site at evergreenshoppe.in.
  To view the site offline, open index.html in Chrome.

2-Logo
  The final logo files.
  - EverGreen-Shoppe-logo-transparent.png: no background, for printing,
    stickers and social media.
  - EverGreen-Shoppe-logo-satin.png: on the satin background.
  - EverGreen-Shoppe-logo.pdf: for print.
  - EverGreen-Shoppe-logo.svg: for any tool that asks for an SVG.
    The SVG holds the high-resolution logo image inside it.

HOSTING AND DOMAIN

The site is hosted free on GitHub Pages.
The domain evergreenshoppe.in is registered at GoDaddy.

DNS records at GoDaddy:
  4 A records:
    185.199.108.153
    185.199.109.153
    185.199.110.153
    185.199.111.153
  www: CNAME record.

To host the site anywhere else, upload the contents of 1-Website.

ORDERS AND CONTACT

The site has no online payment.
"Add to bag" and every product send the order to WhatsApp
+91 79046 98007.

Products and prices are in the PRODUCTS / WB / WG lists inside index.html.

Photo credits: the temple photo is by Madhuranthakan Jagadeesan,
licensed CC BY-SA 4.0. The licence requires the credit to stay
visible on the site; it is shown in the footer. Other credits are in
img/real/CREDITS.txt.

Website by shawn webstudio.
